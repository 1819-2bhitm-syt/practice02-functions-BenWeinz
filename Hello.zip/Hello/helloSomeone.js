function hello(name){
    console.log("Hallo " + name + "!")
}

hello("Ben Weinzierl");